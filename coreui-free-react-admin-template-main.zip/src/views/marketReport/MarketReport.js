import React from 'react'
import ChartRender from './ChartRender'
const MarketReport = () => {
  return <ChartRender />
}

export default MarketReport

import React from 'react'
import { CCol, CRow } from '@coreui/react'

const Buttons = () => {
  return (
    <CRow>
      <CCol xs={12}></CCol>
    </CRow>
  )
}

export default Buttons

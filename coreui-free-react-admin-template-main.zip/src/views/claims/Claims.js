import React from 'react'
import ChartRender from './ChartRender'

const Claims = () => {
  return <ChartRender />
}

export default Claims
